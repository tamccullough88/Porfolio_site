# React Builder

### Quick Start

Run in terminal this command:

```bash
npm install
```

Then run this command to start your local server

```bash
npm start
```
