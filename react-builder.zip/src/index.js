import { render } from 'react-dom'

import Root from './Root.js'

const rootElement = document.getElementById('root')
render(<Root />, rootElement)
